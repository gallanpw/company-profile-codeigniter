<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <div class="gallery">
            <ul>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/1.jpg" title="satu">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-1.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/2.jpg" title="Dua">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-2.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/3.jpg" title="Tiga">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-3.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/4.jpg" title="Empat">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-4.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/5.jpg" title="Lima">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-5.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/6.jpg" title="Enam">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-6.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/7.jpg" title="Tujuh">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-7.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" title="Delapan">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-8.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/9.jpg" title="Sembilan">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-9.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/10.jpg" title="Sepuluh">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-10.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/11.jpg" title="Sebelas">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-11.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/12.jpg" title="Dua belas">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-12.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/13.jpg" title="Tiga belas">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-13.jpg" alt="remeccon" />
                    </a>
                </li>
                <li>
                    <a href="<?php echo base_url(); ?>assets/img/portfolio/14.jpg" title="Empat belas">
                        <img src="<?php echo base_url(); ?>assets/img/portfolio/thumb/portfolio-14.jpg" alt="remeccon" />
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>