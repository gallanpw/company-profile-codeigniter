<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <h2>Profile Perusahaan</h2>
        <p>
            Pada tahun 2013 Remeccon Gemilang Perkasa berdiri di surabaya dan mulai menjalankan bisnis sebagai distributor alat perikanan khususnya Cool Box. Awalnya Remeccon Gemilang Perkasa hanya melayani penjualan/distribusi di wilayah Jawa Timur dan sekitarnya.
            Di tahun yang sama, Conn Distindo berkembang menjadi satu satunya perusahaan distributor Cool Box terbesar di Surabaya dengan pangsa pasar hampir seluruh wilayah Indonesia baik pemerintahan maupun swasta.
            Remeccon Gemilang Perkasa pada tahun 2015 yang akan datang akan mengembangkan usahanya dengan menjual produk produk yang terbuat dari bahan plastic seperti pallet, keranjang, water tank (tangki air), dll.
            Remeccon Gemilang Perkasa mempunyai komitmen untuk melayani dengan baik serta dengan sungguh sungguh memberikan pelayanan prima serta memberikan produk yang berkualitas.
            Keunggulan dan nilai tambah dari Conn Distindo terletak pada kreatifitas dan inovasi dalam mengantisipasi perubahan perubahan yang terjadi terhadap keinginan maupun kebutuhan pelanggan baik rekanan pemerintahan, perusahaan swasta, maupun masyarakat.
        </p><br>
        
        <h3>VISI</h3>
        <p>
            - Menjadi perusahaan distribusi terbaik di Indonesia dengan sistem yang terintegrasi dan produk yang berkualitas.
        </p>
        
        <h3>MISI</h3>
        <p>- Memberikan pelayanan/after sales service yang baik.</p>
        <p>- Menjaga komunikasi yang baik dan memuaskan pelanggan.</p>
    </div><br><br>
</div>