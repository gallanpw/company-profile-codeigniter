<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <section class="post">
            <img src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice-crusher" />
            <div class="post-cnt">
                <h2>Ice Crusher</h2>
                <p><strong>Spesifikasi Teknis :</strong></p>
                <p>
                        Kapasitas penggerusan : <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ~ 1 ton per - jam <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ~ 1 ton per - hari <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ~ 2 ton per - jam <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; ~ 2 ton per - hari <br>
                        Ukuran balok es : penggerusan ukuran balok es 5kg sampai dengan 100 kg <br>
                        Ukuran Hooper : disesuaikan dengan ukuran es. <br>
                        Konsumsi listrik : 2kw-5.5KW <br>
                        Control box : <br>
                        - Control RPM (mode 1 - mode5), mode adalah tingkatan kecepatan putaran penggerusan balok es <br>
                        - Control timer, penyesuaian waktu penggerusan (untuk keamanan) <br>
                        - Adjustable (dapat disesuaikan) dengan system conveyer, meja berjalan (untuk keamanan) <br>
                </p>
                <p><strong>CONN Ice Crusher (pemecah es)</strong></p>
                <p>
                        Kualitas tinggi untuk industri es atau yang membutuhkan jenis kapasitas dan bentuk/ukuran es yang diinginkan dari penghancuran balok es batu. <br>
                        Mesin mudah dioperasikan. <br>
                        Anti korosi <br>
                        Mudah dibersihkan, pemeliharaan untuk mesin kami sangat rendah <br>
                        Terbuat dari bahan Stainless Steel, tahan lama, anti-karat dan bebas korosi <br>
                        Desain kinerja mesin dan teruji tahan lebih dari 10 tahun. <br>
                        Dilengkapi dengan switch dan control box electric <br>
                        Rangka mesin <br>
                        Penghancuran Balok Es menjadi potongan dan serpihan kecil lembut <br>
                        Konsumsi listrik relative rendah <br>
                        Rangka mesin dari bahan baja anti karat <br>
                        Tersedia beberapa jenis berdasarkan penampang dan dimensinya mohon konsultasikan dengan kami untuk kebutuhan anda <br>
                </p>
            </div>
            <!--<div class="cl">&nbsp;</div>-->
        </section>

        <h3>Produk Kami Lainnya</h3>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>pullverizer-mill/">
                    <img src="<?php echo base_url(); ?>assets/img/pullverizer/pullverizer.png" alt="pullverizer-mill" />
                    <div class="teks">Pullverizer Mill</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>mesin-rotomolding/">
                    <img src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin-rotomolding" />
                    <div class="teks">Mesin Rotomolding</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-flake/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice-flake" />
                    <div class="teks">Mesin Pembuat Es</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>biji-plastik/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/9.jpg" alt="jual-biji-plastik" />
                    <div class="teks">Jual Biji Plastik</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>jasa-giling/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa-giling-biji-plastik" />
                    <div class="teks">Jasa Giling Biji Plastik</div>
                </a>
            </div>
        </div>
    </div>
</div>