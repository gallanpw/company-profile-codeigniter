<!-- Content START -->
<div class="container">
		<!-- Three columns of text below the carousel -->
		<div class="row">
				<div class="col-lg-4">
						<a href="<?php echo site_url('pullverizer-mill'); ?>"><img class="img-thumbnail" src="<?php echo base_url(); ?>assets/img/pullverizer/pullverizer.png" alt="pullverizer-mill"></a>
						<h2>Pullverizer Mill</h2>
						<p>Untuk keterangan Produk Pullverizer Mill lebih lanjut, bisa klik link di bawah ini !</p>
						<p><a class="btn btn-default" href="<?php echo site_url('pullverizer-mill'); ?>" role="button">Detail Produk &raquo;</a></p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-4">
						<a href="<?php echo site_url('mesin-rotomolding'); ?>"><img class="img-thumbnail" src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin-rotomolding"></a>
						<h2>Mesin Rotomolding</h2>
						<p>Untuk keterangan Produk Mesin Rotomolding lebih lanjut, bisa klik link di bawah ini !</p>
						<p><a class="btn btn-default" href="<?php echo site_url('mesin-rotomolding'); ?>" role="button">Detail Produk &raquo;</a></p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-4">
						<a href="<?php echo site_url('ice-crusher'); ?>"><img class="img-thumbnail" src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice-crusher"></a>
						<h2>Ice Crusher</h2>
						<p>Untuk keterangan Produk Ice Crusher lebih lanjut, bisa klik link di bawah ini !</p>
						<p><a class="btn btn-default" href="<?php echo site_url('ice-crusher'); ?>" role="button">Detail Produk &raquo;</a></p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-4">
						<a href="<?php echo site_url('ice-flake'); ?>"><img class="img-thumbnail" src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice-flake"></a>
						<h2>Ice Flake</h2>
						<p>Untuk keterangan Produk Ice Flake lebih lanjut, bisa klik link di bawah ini !</p>
						<p><a class="btn btn-default" href="<?php echo site_url('ice-flake'); ?>" role="button">Detail Produk &raquo;</a></p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-4">
						<a href="<?php echo site_url('biji-plastik'); ?>"><img class="img-thumbnail" src="<?php echo base_url(); ?>assets/img/portfolio/9.jpg" alt="jual-biji-plastik"></a>
						<h2>Jual Biji Plastik</h2>
						<p>Untuk keterangan Produk Biji Plastik lebih lanjut, bisa klik link di bawah ini !</p>
						<p><a class="btn btn-default" href="<?php echo site_url('biji-plastik'); ?>" role="button">Detail Produk &raquo;</a></p>
				</div><!-- /.col-lg-4 -->
				<div class="col-lg-4">
						<a href="<?php echo site_url('jasa-giling'); ?>"><img class="img-thumbnail" src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa-giling-biji-plastik"></a>
						<h2>Jasa Giling Biji Plastik</h2>
						<p>Untuk keterangan Jasa Giling Biji Plastik lebih lanjut, bisa klik link di bawah ini !</p>
						<p><a class="btn btn-default" href="<?php echo site_url('jasa-giling'); ?>" role="button">Detail Produk &raquo;</a></p>
				</div><!-- /.col-lg-4 -->
		</div><!-- /.row -->
</div><!-- /.container -->