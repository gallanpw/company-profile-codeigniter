<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>pullverizer-mill/">
                    <img src="<?php echo base_url(); ?>assets/img/pullverizer/pullverizer.png" alt="pullverizer mill" />
                    <div class="teks">Pullverizer Mill</div>
                </a>
                <!--<div class="col-cnt">
                    <h2>Pullverizer Mill</h2>
                    <p>Klik pada gambar untuk keterangan produk lebih lanjut atau klik pada Link di bawah ini.</p>
                    <a href="#" class="more">Klik Di Sini</a>
                </div>-->
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>mesin-rotomolding/">
                    <img src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin rotomolding" />
                    <div class="teks">Mesin Rotomolding</div>
                </a>
                <!--<div class="col-cnt">
                    <h2>Rotomolding</h2>
                    <p>Klik pada gambar untuk keterangan produk lebih lanjut atau klik pada Link di bawah ini.</p>
                    <a href="#" class="more">Klik Di Sini</a>
                </div>-->
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-crusher/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice crusher" />
                    <div class="teks">Ice Crusher</div>
                </a>
                <!--<div class="col-cnt">
                    <h2>Ice Crusher</h2>
                    <p>Klik pada gambar untuk keterangan produk lebih lanjut atau klik pada Link di bawah ini.</p>
                    <a href="#" class="more">Klik Di Sini</a>
                </div>-->
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-flake/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice flake" />
                    <div class="teks">Mesin Pembuat Es</div>
                </a>
                <!--<div class="col-cnt">
                    <h2>Ice Crusher</h2>
                    <p>Klik pada gambar untuk keterangan produk lebih lanjut atau klik pada Link di bawah ini.</p>
                    <a href="#" class="more">Klik Di Sini</a>
                </div>-->
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>jasa-giling/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa giling" />
                    <div class="teks">Jasa Giling Bubuk Plastik</div>
                </a>
                <!--<div class="col-cnt">
                    <h2>Ice Crusher</h2>
                    <p>Klik pada gambar untuk keterangan produk lebih lanjut atau klik pada Link di bawah ini.</p>
                    <a href="#" class="more">Klik Di Sini</a>
                </div>-->
            </div>
        </div>
    </div><br><br>
</div>