<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <section class="post">
            <img src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice-flake" />
            <div class="post-cnt">
                <h2>Ice Flake</h2>
                <p>Mesin pembuat es dari air laut ini digunakan untuk industri pengolahan hasil tangkap / bahan makanan yang berasal dari laut.</p>
                <p>Hasil produksi es berbentuk serpihan , cocok untuk proses pendinginan hasil tangkap perikanan dan kelautan.</p>
                <br><p style="color: red;">NB : ES TIDAK UNTUK DIMAKAN.</p>
                <p>Menggunakan komponen rakitan mesin yang berkualitas dari Jerman , Italia dan Denmark.</p>
                <br><br>
            </div>
            <!--<div class="cl">&nbsp;</div>-->
        </section>

        <h3>Produk Kami Lainnya</h3>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>pullverizer-mill/">
                    <img src="<?php echo base_url(); ?>assets/img/pullverizer/pullverizer.png" alt="pullverizer-mill" />
                    <div class="teks">Pullverizer Mill</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>mesin-rotomolding/">
                    <img src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin-rotomolding" />
                    <div class="teks">Mesin Rotomolding</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-crusher/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice-crusher" />
                    <div class="teks">Ice Crusher</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>biji-plastik/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/9.jpg" alt="jual-biji-plastik" />
                    <div class="teks">Jual Biji Plastik</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>jasa-giling/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa-giling-biji-plastik" />
                    <div class="teks">Jasa Giling Biji Plastik</div>
                </a>
            </div>
        </div>
    </div>
</div>