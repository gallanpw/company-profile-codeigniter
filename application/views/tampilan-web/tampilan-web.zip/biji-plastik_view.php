<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <section class="post">
            <img src="<?php echo base_url(); ?>assets/img/portfolio/9.jpg" alt="jual-biji-plastik" />
            <div class="post-cnt">
                <h2>Jual biji plastik baru atau recycle dan bubuk plastik </h2>
                <p>
                    jenis plastik; pe , hdpe , lldpe , mdpe , abs , eva , pvc , pp dll<br>

                    ukuran tepung = mm - micron , mesh 20 - 100<br>
                    
                    untuk kebutuhan<br>
                    - produksi roto mould / roto molding thermoplastik<br>
                    - produksi inject / injeksi plastik<br>
                    - produksi tangki air, drum dll<br>
                    
                    kapasitas mesin giling kami : 200 s/d 1000 kg - perhari<br>
                    
                    untuk kebutuhan khusus anda dapat menghubungi kami langsung<br>
                    
                    NB: kami juga melayani penjualan mesin giling pulveriser mill dan bubuk plastik jadi<br>
                    
                    harga giling / kg : Rp 4000<br>
                    
                    kami sepenuh hati memberikan konsultasi dan one stop solution untuk kebutuhan anda<br>
                </p>
            </div>
            <!--<div class="cl">&nbsp;</div>-->
        </section>

        <h3>Produk Kami Lainnya</h3>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>pullverizer-mill/">
                    <img src="<?php echo base_url(); ?>assets/img/pullverizer/pullverizer.png" alt="pullverizer-mill" />
                    <div class="teks">Pullverizer Mill</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>mesin-rotomolding/">
                    <img src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin-rotomolding" />
                    <div class="teks">Mesin Rotomolding</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-crusher/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice-crusher" />
                    <div class="teks">Ice Crusher</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-flake/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice-flake" />
                    <div class="teks">Mesin Pembuat Es</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>jasa-giling/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa-giling-biji-plastik" />
                    <div class="teks">Jasa Giling Biji Plastik</div>
                </a>
            </div>
        </div>
    </div>
</div>