<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <section class="post">
            <img src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin-rotomolding" />
            <div class="post-cnt">
                <h2>Mesin roto moulding thermoplastik conn</h2>
                <p>mesin ini memproduksi cool box dan tutup pada satu mesin</p> 
                <p>cool box mempunyai</p>
                <p>- 2 lapis dinding tanpa sambungan</p>
                <p>- insulasi dalam atau diinject bahan isolasi suhu polyurethane hardness 40 - 45</p>
                <p>- lubang hidran</p>		
                <p>disini kami memberikan mesin dengan system pembakaran terbuka tanpa ruang oven</p>
                <p>
                    - tangki tandon atau drum air<br>
                    - kapal besar kecil nelayan tangkap plastik<br>
                    - kayak / perahu kecil plastik<br>
                    - furniture<br>
                    - pelampung pipa, bola , lonjong<br>
                    - bola kontruksi / bubble deck<br>
                    - kabel roll / haspel / hasple<br>
                    - cool box<br>
                    - traffic cone<br>
                    
                    dan masih banyak aplikasi produk lainnya<br>
                    
                    fitur mesin :<br>
                    
                    - aplikasi manual atau automation PLC<br>
                    - burner system<br>
                    - shuttle oven system<br>
                    
                    menerima jasa pembuatan<br>
                    - matrass / cetakan / mould roto mold / moulding ;
                    plat besi , stainless / allumunium
                </p>
                <p>
                        - Rock n Roll
                        1000, 2000, 3000, 5000, 10.000
                </p>
                <p>
                        - Biaxial
                        1 Arm, 2 Arm, 4 Arm								
                </p>
            </div>
            <!--<div class="cl">&nbsp;</div>-->
        </section>

        <h3>Produk Kami Lainnya</h3>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>pullverizer-mill/">
                    <img src="<?php echo base_url(); ?>assets/img/pullverizer/pullverizer.png" alt="pullverizer-mill" />
                    <div class="teks">Pullverizer Mill</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-crusher/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice-crusher" />
                    <div class="teks">Ice Crusher</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-flake/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice-flake" />
                    <div class="teks">Mesin Pembuat Es</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>biji-plastik/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/9.jpg" alt="jual-biji-plastik" />
                    <div class="teks">Jual Biji Plastik</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>jasa-giling/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa-giling-biji-plastik" />
                    <div class="teks">Jasa Giling Biji Plastik</div>
                </a>
            </div>
        </div>
    </div>
</div>