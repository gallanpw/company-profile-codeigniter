<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <section class="post">
            <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="ice flake" />
            <div class="post-cnt">
                <h2>Jasa Pabrikasi (Pembuatan) Berbagai Polyurethane </h2>
                <p>
                    Kami menerima pabrikasi (pembuatan) berbagai bentuk rubber dan polyurethane sesuai dengan pesanan, ukuran/gambar tanpa adanya minimum order serta kami juga dapat menerima machining sesuai kebutuhan anda.
                    
                    kami sepenuh hati memberikan konsultasi dan one stop solution untuk kebutuhan anda<br><br><br><br><br><br><br><br><br><br>
                </p>
            </div>
            <!--<div class="cl">&nbsp;</div>-->
        </section>

        <h3>Produk Kami Lainnya</h3>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>pullverizer-mill/">
                    <img src="<?php echo base_url(); ?>assets/img/pullverizer/pullverizer.png" alt="pullverizer mill" />
                    <div class="teks">Pullverizer Mill</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>mesin-rotomolding/">
                    <img src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin rotomolding" />
                    <div class="teks">Mesin Rotomolding</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-crusher/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice crusher" />
                    <div class="teks">Ice Crusher</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-flake/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice flake" />
                    <div class="teks">Mesin Pembuat Es</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>jasa-giling/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa giling" />
                    <div class="teks">Jasa Giling Bubuk Plastik</div>
                </a>
            </div>
        </div>
    </div>
</div>