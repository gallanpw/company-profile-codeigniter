<!-- Content START -->
<div class="container">
    <div class="row"><br><br>
        <section class="post">
            <img src="<?php echo base_url(); ?>assets/img/pullverizer/1.png" alt="pullverizer-mill" />
            <div class="post-cnt">
                <h2>Mesin Giling Pullverizer Mill</h2>
                <p>Kami melayani Jasa Giling biji plastik menjadi tepung / bubuk plastik</p> 
                <p>untuk kebutuhan produksi thermoplastik / inject plastik</p>
                <p>dengan mesh 20 - 100 , milimeter s/d micron mesh</p>
                <p>Mesin kami dapat melayani Kapasitas 500 kg, 1000 kg, 2000 kg, 5000 kg / hari , 25 kg / jam</p>
                <p>untuk kebutuhan lebih atau lebih spesifik dapat dikonsultasikan dengan kami</p>
                <p>jenis mesin Mill type :</p> 
                <p>- Twin Drum</p>
                <p>- Grind disc</p>
                <p>- Hammer Mill</p>
                <p>output powder :</p>
                <p>- mesh 20 - 100 , filter screen adjustment , dapat disesuaikan kebutuhan output dengan system filter</p>
                <p>- filter : 3 mm - 1 mm , hasil output millimeter - micron</p>
                <p>cooling system : water</p>
                <p>penyusutan : kurang lebih 12%</p>
                <p>Fitur :</p>
                <p>- Dapat melayani untuk jenis biji plastik baru/ pellet untuk menjadi bubuk</p>
                <p>- Dapat melayani untuk jenis plastik recycle / avalan crusher untuk menjadi bubuk</p>
            </div>
            <!--<div class="cl">&nbsp;</div>-->
        </section>

        <h3>Produk Kami Lainnya</h3>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>mesin-rotomolding/">
                    <img src="<?php echo base_url(); ?>assets/img/rotomolding/rotomolding.png" alt="mesin-rotomolding" />
                    <div class="teks">Mesin Rotomolding</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-crusher/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-crusher/ice-crusher.png" alt="ice-crusher" />
                    <div class="teks">Ice Crusher</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>ice-flake/">
                    <img src="<?php echo base_url(); ?>assets/img/ice-flake/ice-flake.png" alt="ice-flake" />
                    <div class="teks">Mesin Pembuat Es</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>biji-plastik/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/9.jpg" alt="jual-biji-plastik" />
                    <div class="teks">Jual Biji Plastik</div>
                </a>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="gambar">
                <a href="<?php echo base_url(); ?>jasa-giling/">
                    <img src="<?php echo base_url(); ?>assets/img/portfolio/8.jpg" alt="jasa-giling-biji-plastik" />
                    <div class="teks">Jasa Giling Biji Plastik</div>
                </a>
            </div>
        </div>
    </div>
</div>